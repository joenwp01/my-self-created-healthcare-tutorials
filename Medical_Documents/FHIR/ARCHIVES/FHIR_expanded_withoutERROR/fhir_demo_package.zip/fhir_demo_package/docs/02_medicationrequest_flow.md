# Demo 2: MedicationRequest Flow

## Goal

This demo shows how a medication order becomes a FHIR `MedicationRequest` plus its supporting linked resources.

## Why this demo matters

Medication data is often messy because source systems may use local drug text, free-text directions, and local status codes. To exchange medication data cleanly, those source values usually need to be normalized and coded.

## Significant steps in expected operation

### Station 1: Inbound medication order

The source row contains:

- order ID
- patient MRN
- local medication text
- SIG or dose instruction text
- start date
- source status
- provider name

At this point, the order is just source-system prescribing content.

### Station 2: Parse medication fields

The pipeline separates the row into:

- order identity
- patient key
- medication text
- SIG text
- authored date
- status
- prescriber

This makes later mapping easier.

### Station 3: Normalize status and code the drug

The pipeline performs important conversions:

- local medication text is mapped to an RxNorm concept
- source status is mapped to a FHIR medication request status
- the intent is identified as an order

This is the step that makes the drug comparable across organizations.

### Station 4: Build MedicationRequest bundle

The pipeline builds linked FHIR resources such as:

- `Patient`
- `Practitioner`
- `MedicationRequest`

The `MedicationRequest` references the patient and requester and carries the medication coding and dosage instruction.

### Station 5: Flatten for medication analytics

The linked FHIR data is flattened into a row for medication reporting, usually including:

- patient ID
- medication request ID
- RxNorm code
- medication display text
- request status
- authored date
- prescriber
- SIG

## Transformation concepts shown

- source medication text to standard coding
- source status to FHIR status
- free-text instructions preserved as dosage text
- request linking to patient and prescriber
- analytics flattening after exchange shaping

## Practical lesson

MedicationRequest is usually the exchange shape. Medication reporting tables are usually the analytics shape.
