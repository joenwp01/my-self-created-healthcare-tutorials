# Demo 3: C-CDA or CSV into FHIR

## Goal

This demo shows how semi-structured or tabular source data can be transformed into a native FHIR resource.

## Why this demo matters

Healthcare teams often do not start with FHIR-native data. They may start from:

- a C-CDA clinical document
- a CSV export from an EHR or registry
- a transformation landing table

This demo shows the logic needed to convert that source content into a standard FHIR `Condition` resource.

## Significant steps in expected operation

### Station 1: Source document or extract arrives

The pipeline receives either:

- a C-CDA problem observation snippet
- a CSV row containing a diagnosis

At this stage, the data is not yet FHIR even if it already contains clinical coding.

### Station 2: Extract structured fields

The pipeline pulls out the meaningful facts, such as:

- patient MRN
- diagnosis code
- diagnosis text
- onset date
- optional alternative coding such as SNOMED CT

This is the extraction step.

### Station 3: Map and reconcile coding

The pipeline decides how to represent the diagnosis in a standardized way. It may preserve:

- ICD-10-CM coding
- SNOMED CT coding
- human-readable text

This step is critical because source content may carry multiple useful coding systems.

### Station 4: Build FHIR resource

The pipeline creates a FHIR `Condition` resource with:

- standardized coding
- condition text
- patient reference
- onset date

This is the point where the source is converted into native FHIR.

### Station 5: Export or warehouse load

After the conversion, the pipeline may do one of two things:

- store or send the resource as FHIR
- flatten the fact into a warehouse table row

This demo shows the warehouse form as the final teaching step.

## Transformation concepts shown

- XML or CSV extraction
- multi-coding preservation
- mapping into a single FHIR resource
- optional post-FHIR flattening

## Practical lesson

FHIR often sits in the middle of the pipeline, not always at the very beginning and not always at the very end.
