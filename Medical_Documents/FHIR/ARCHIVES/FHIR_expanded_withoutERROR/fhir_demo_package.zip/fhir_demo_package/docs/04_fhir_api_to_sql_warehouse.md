# Demo 4: FHIR API Response into SQL Warehouse Row

## Goal

This demo shows how data that is already in FHIR format still needs additional work before it becomes warehouse-ready.

## Why this demo matters

Many teams assume that once data is returned from a FHIR API, it is immediately ready for analytics. In practice, FHIR payloads are usually nested JSON with references to other resources. That is excellent for interoperability, but not ideal for most SQL analytics.

## Significant steps in expected operation

### Station 1: FHIR API response arrives

The pipeline receives a FHIR `Bundle` or resource response, such as an `Observation` search result.

The response may already include:

- code and display
- patient reference
- encounter reference
- date and time
- result value and unit

The key limitation is that the structure is still nested and reference-based.

### Station 2: Extract relevant fields

The pipeline pulls out the fields needed for reporting and creates a flatter intermediate object.

This usually includes:

- observation ID
- code
- display text
- patient reference
- encounter reference
- result value
- unit
- effective time

### Station 3: Resolve references and dimensions

The pipeline maps FHIR references such as:

- `Patient/patient-445566`
- `Encounter/enc-1001`

into warehouse dimensions or trusted business identifiers.

This step is often where:

- identity matching
- dimension lookups
- master data reconciliation

happens.

### Station 4: Load warehouse row

The resolved data is inserted into a fact table such as `fact_lab_result`.

This is the warehouse-ready shape.

### Station 5: Optional SQL transform view

The warehouse may then expose curated marts or views on top of the raw fact table.

This is often what BI users and analysts actually query.

## Transformation concepts shown

- FHIR JSON extraction
- reference resolution
- dimension key assignment
- warehouse fact load
- curated semantic layer creation

## Practical lesson

FHIR can be the source for analytics pipelines, but most analytics teams still need a dedicated transformation layer after the FHIR API call.
