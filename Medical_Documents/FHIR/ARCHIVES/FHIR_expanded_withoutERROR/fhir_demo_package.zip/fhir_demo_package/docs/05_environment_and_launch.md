# Environment and Launch Instructions

## Purpose

This document explains the simplest environment for running the multi-flow demo locally.

## Recommended environment

Use a lightweight React environment.

### Prerequisites

- Node.js 20 or newer
- npm or pnpm
- a browser such as Chrome or Edge

## Option 1: Vite React app

### Create the project

```bash
npm create vite@latest fhir-demo -- --template react
cd fhir-demo
npm install
```

### Add Tailwind CSS

Install and configure Tailwind CSS for your Vite React version.

The component uses Tailwind utility classes extensively, so Tailwind should be active before launch.

### Add the demo component

Copy the file:

```text
fhir_multi_flow_station_demo.jsx
```

into your project under:

```text
src/FhirMultiFlowStationDemo.jsx
```

### Update App.jsx

Replace your default `App.jsx` with:

```jsx
import FhirMultiFlowStationDemo from "./FhirMultiFlowStationDemo";

export default function App() {
  return <FhirMultiFlowStationDemo />;
}
```

### Run locally

```bash
npm run dev
```

Open the local URL that Vite prints in the terminal.

## Option 2: Use it in ChatGPT canvas

The same multi-flow component was created in canvas format, which allows direct interaction without any local Node environment.

## What you should see

When the app launches, you should be able to:

- choose one of the four flows
- see the current station title and purpose
- toggle between before and after states
- click **Apply change and continue** to move to the next station
- restart a flow at any time

## Intended use

This is a teaching and explanation demo, not a production FHIR transformer. The examples are simplified on purpose so you can see the sequence of operations clearly.

## Suggested extensions

If you want to grow the demo later, good additions would be:

- profile validation checkpoints
- terminology service lookup simulation
- identifier matching failure cases
- error branch paths
- bulk FHIR export simulation
- SQL DDL for target warehouse tables
