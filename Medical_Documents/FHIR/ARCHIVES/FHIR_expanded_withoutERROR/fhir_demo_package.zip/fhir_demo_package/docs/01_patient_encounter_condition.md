# Demo 1: Patient + Encounter + Condition

## Goal

This demo shows how a simple registration and diagnosis row becomes three connected FHIR resources:

- Patient
- Encounter
- Condition

It also shows the final step where those linked resources are flattened into one SQL-friendly row for reporting.

## Why this demo matters

A lot of useful clinical data starts life as a row in an operational system. That row often mixes person data, visit context, and diagnosis facts together. FHIR does not keep those as one flat object. Instead, it separates them into linked resources.

This demo helps show why the transformation is needed and what is gained by doing it.

## Significant steps in expected operation

### Station 1: Inbound source row

The source arrives as a flat row containing:

- patient MRN
- patient name
- date of birth
- sex
- visit identifier
- visit date
- department
- diagnosis code
- diagnosis text

At this point, the row is still only source-system data.

### Station 2: Parse and identify core entities

The pipeline splits the row into logical buckets:

- patient data
- encounter data
- condition data

This is the point where the pipeline starts understanding what the pieces mean.

### Station 3: Normalize and validate

The pipeline makes the values cleaner and more interoperable:

- MRN becomes a stable patient identifier pattern
- sex becomes FHIR gender style
- the visit is recognized as an ambulatory encounter
- the diagnosis code is explicitly attached to an ICD-10-CM code system

This step is important because raw source values are usually too inconsistent to trust across systems.

### Station 4: Build linked FHIR resources

The pipeline creates:

- `Patient`
- `Encounter`
- `Condition`

The `Condition` points to the `Patient` and `Encounter` using references.

This is where the data becomes an interoperable FHIR representation.

### Station 5: Flatten for SQL analytics

The linked FHIR resources are turned into one row with fields such as:

- patient ID
- encounter ID
- condition code
- condition display
- visit date
- service line

This is often the shape that analysts, quality teams, dashboards, and warehouse jobs want.

## Transformation concepts shown

- splitting one row into multiple entities
- assigning stable identifiers
- attaching code systems
- building linked FHIR resources
- flattening graph data into tabular data

## Practical lesson

FHIR is very good for exchange and application integration, but many analytics users still want a flattened row after the FHIR step is complete.
